'''from flask import Flask, jsonify
from authlib.integrations.flask_client import OAuth

app = Flask(__name__)
oauth = OAuth(app)

# Auth0 configuration
oauth.register(
    name='auth0',
    client_id='YOUR_AUTH0_CLIENT_ID',
    client_secret='YOUR_AUTH0_CLIENT_SECRET',
    server_metadata_url='https://YOUR_AUTH0_DOMAIN/.well-known/openid-configuration',
    client_kwargs={
        'scope': 'openid profile email',
        'audience': 'https:\\amazon-reviews.net',  # Include your API identifier here

    },
)

# Auth middleware
@app.before_request
def require_auth():
    if not oauth.auth0.authorized:
        return jsonify(message='Unauthorized'), 401

# Protected route
@app.route('/authorized')
def authorized():
    return 'Secured Resource'

if __name__ == '__main__':
    app.run(debug=True)
'''

import json
from os import environ as env
from urllib.parse import quote_plus, urlencode

from authlib.integrations.flask_client import OAuth
from dotenv import find_dotenv, load_dotenv
from flask import Flask, redirect, render_template, session, url_for

ENV_FILE = find_dotenv()
if ENV_FILE:
    load_dotenv(ENV_FILE)

app = Flask(__name__)
app.secret_key = env.get("APP_SECRET_KEY") #e61de153fb483642f1ca67954343cd05aef81184c290a3b8201a1136adfe8379

oauth = OAuth(app)

#TODO urls

oauth.register(
    "auth0",
    client_id=env.get("AUTH0_CLIENT_ID"),
    client_secret=env.get("AUTH0_CLIENT_SECRET"),
    client_kwargs={
        "scope": "openid profile email",
    },
    server_metadata_url=f'https://{env.get("AUTH0_DOMAIN")}/.well-known/openid-configuration'
)
'''
# Initialize ResourceProtector and Auth0JWTBearerTokenValidator
require_auth = ResourceProtector()
validator = Auth0JWTBearerTokenValidator(
    env.get("AUTH0_DOMAIN"),
    "https:\\amazon-reviews.net" 
)
require_auth.register_token_validator(validator)
'''
@app.route("/login")
def login():
    return oauth.auth0.authorize_redirect(redirect_uri=url_for("callback", _external=True))

@app.route("/callback", methods=["GET", "POST"])
def callback():
    token = oauth.auth0.authorize_access_token()
    session["user"] = token
    return redirect("/")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(
        "https://" + env.get("AUTH0_DOMAIN")
        + "/v2/logout?"
        + urlencode(
            {
                "returnTo": url_for("home", _external=True),
                "client_id": env.get("AUTH0_CLIENT_ID"),
            },
            quote_via=quote_plus,
        )
    )

@app.route("/")
def home():
    return render_template("home.html", session=session.get('user'), pretty=json.dumps(session.get('user'), indent=4))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=env.get("PORT", 50005))

    """Python Flask API Auth0 integration example
"""
'''
from os import environ as env

from dotenv import load_dotenv, find_dotenv
from flask import Flask, jsonify
from authlib.integrations.flask_oauth2 import ResourceProtector
from validator import Auth0JWTBearerTokenValidator

require_auth = ResourceProtector()
validator = Auth0JWTBearerTokenValidator(
    "dev-h2k5uttlw0fkxdod.us.auth0.com",
    "{yourApiIdentifier}"
)
require_auth.register_token_validator(validator)

APP = Flask(__name__)


@APP.route("/api/public")
def public():
    """No access token required."""
    response = (
        "Hello from a public endpoint! You don't need to be"
        " authenticated to see this."
    )
    return jsonify(message=response)


@APP.route("/api/private")
@require_auth(None)
def private():
    """A valid access token is required."""
    response = (
        "Hello from a private endpoint! You need to be"
        " authenticated to see this."
    )
    return jsonify(message=response)


@APP.route("/api/private-scoped")
@require_auth("read:messages")
def private_scoped():
    """A valid access token and scope are required."""
    response = (
        "Hello from a private endpoint! You need to be"
        " authenticated and have a scope of read:messages to see"
        " this."
    )
    return jsonify(message=response)'''