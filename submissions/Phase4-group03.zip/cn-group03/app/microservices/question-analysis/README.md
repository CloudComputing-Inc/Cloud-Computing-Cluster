setup instructions

Server:
$ python -m venv venv
$ source venv/bin/activate

(venv) $ cd ~/cn-group03/app/microservices/question-analysis
(venv) $ python -m pip install -r requirements.txt

